﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            this.Hide();
            form2.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string producto = txtpro.Text;
            string descripcion = txtdes.Text;
            string precio = txtpre.Text;
            string fecha = txtfe.Text;
            string Categoria = txtcat.Text;
            string Proveedor = txtprov.Text;


            if (txtpro.Text == "producto" || txtdes.Text == "descripcion" || txtpre.Text == "precio" || txtfe.Text == "fecha" || txtcat.Text == "Categoria" || txtprov.Text == "Provedor" )
            {
                MessageBox.Show("Por favor ingresar datos");
            }
            else
            {
                conexion.Open();
                string cadena = "insert into producto(codigo,producto,existencias,precio) values ('" + Codigo + "','" + Producto + "','" + Existencias + "','" + Precio + "')";
                MySqlCommand comando = new MySqlCommand(cadena, conexion);
                comando.ExecuteNonQuery();

                MessageBox.Show("Los datos se guardaron éxitosamente");

                codigo.Text = "";
                producto.Text = "";
                existencias.Text = "";
                precio.Text = "";

                string cadena2 = "select * from Producto";

                MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena2, conexion);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                tabla_mostrar.DataSource = dt;


                conexion.Close()
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
