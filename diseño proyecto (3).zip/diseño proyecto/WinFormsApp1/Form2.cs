﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        MySqlConnection conexion = new MySqlConnection("server=localhost; database=tienda; Uid=root; Pwd=;");
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lblfecha.Text = DateTime.Today.Date.ToString("d");
            conexion.Open();
            string consulta = "SELECT productos.nom_producto, productos.descripcion, productos.precio, productos.fecha_producto, categorias.nombre_ca , proveedores.nom_proveedor FROM productos INNER JOIN categorias on categorias.idcategorias = productos.categorias_idcategorias INNER JOIN proveedores_has_productos ON proveedores_has_productos.productos_idproductos = productos.idproductos INNER JOIN proveedores ON proveedores_has_productos.proveedores_idproveedores = proveedores.idproveedores;; ";
            MySqlDataAdapter adaptador = new MySqlDataAdapter(consulta, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;

            conexion.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {


        }




        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

