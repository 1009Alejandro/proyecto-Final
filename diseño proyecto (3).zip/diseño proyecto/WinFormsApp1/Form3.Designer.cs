﻿namespace WinFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtfe = new TextBox();
            label3 = new Label();
            txtprov = new TextBox();
            button2 = new Button();
            txtcat = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtpre = new TextBox();
            txtdes = new TextBox();
            txtpro = new TextBox();
            btnregistrar = new Button();
            mySqlCommand1 = new MySql.Data.MySqlClient.MySqlCommand();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtfe);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtprov);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(txtcat);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtpre);
            groupBox1.Controls.Add(txtdes);
            groupBox1.Controls.Add(txtpro);
            groupBox1.Controls.Add(btnregistrar);
            groupBox1.Location = new Point(23, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(291, 346);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Registro de datos";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // txtfe
            // 
            txtfe.Location = new Point(122, 166);
            txtfe.Name = "txtfe";
            txtfe.Size = new Size(126, 23);
            txtfe.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 265);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 15;
            label3.Text = "Proveedor:";
            // 
            // txtprov
            // 
            txtprov.Location = new Point(122, 265);
            txtprov.Name = "txtprov";
            txtprov.Size = new Size(126, 23);
            txtprov.TabIndex = 14;
            // 
            // button2
            // 
            button2.Location = new Point(173, 317);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 13;
            button2.Text = "regresar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // txtcat
            // 
            txtcat.Location = new Point(122, 210);
            txtcat.Name = "txtcat";
            txtcat.Size = new Size(126, 23);
            txtcat.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(50, 210);
            label6.Name = "label6";
            label6.Size = new Size(59, 15);
            label6.TabIndex = 11;
            label6.Text = "categoria:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(68, 169);
            label5.Name = "label5";
            label5.Size = new Size(41, 15);
            label5.TabIndex = 10;
            label5.Text = "Fecha:";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(66, 121);
            label4.Name = "label4";
            label4.Size = new Size(43, 15);
            label4.TabIndex = 9;
            label4.Text = "Precio:";
            label4.Click += label4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(39, 83);
            label2.Name = "label2";
            label2.Size = new Size(75, 15);
            label2.TabIndex = 7;
            label2.Text = "Descripcion :";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 37);
            label1.Name = "label1";
            label1.Size = new Size(59, 15);
            label1.TabIndex = 6;
            label1.Text = "producto:";
            label1.Click += label1_Click;
            // 
            // txtpre
            // 
            txtpre.Location = new Point(122, 118);
            txtpre.Name = "txtpre";
            txtpre.Size = new Size(126, 23);
            txtpre.TabIndex = 3;
            txtpre.TextChanged += textBox3_TextChanged;
            // 
            // txtdes
            // 
            txtdes.Location = new Point(122, 80);
            txtdes.Name = "txtdes";
            txtdes.Size = new Size(126, 23);
            txtdes.TabIndex = 2;
            // 
            // txtpro
            // 
            txtpro.Location = new Point(122, 34);
            txtpro.Name = "txtpro";
            txtpro.Size = new Size(126, 23);
            txtpro.TabIndex = 1;
            // 
            // btnregistrar
            // 
            btnregistrar.Location = new Point(39, 317);
            btnregistrar.Name = "btnregistrar";
            btnregistrar.Size = new Size(75, 23);
            btnregistrar.TabIndex = 0;
            btnregistrar.Text = "Registrar";
            btnregistrar.UseVisualStyleBackColor = true;
            btnregistrar.Click += button1_Click;
            // 
            // mySqlCommand1
            // 
            mySqlCommand1.CacheAge = 0;
            mySqlCommand1.Connection = null;
            mySqlCommand1.EnableCaching = false;
            mySqlCommand1.Transaction = null;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AliceBlue;
            ClientSize = new Size(344, 370);
            Controls.Add(groupBox1);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label5;
        private Label label4;
        private Label label2;
        private Label label1;
        private TextBox txtpre;
        private TextBox txtdes;
        private TextBox txtpro;
        private Button btnregistrar;
        private TextBox txtcat;
        private Label label6;
        private Button button2;
        private MySql.Data.MySqlClient.MySqlCommand mySqlCommand1;
        private Label label3;
        private TextBox txtprov;
        private TextBox txtfe;
    }
}